=begin
	in this script, first I want to show in the output the script`s 
	objective, and it is practice the operators learned in ruby language
=end
puts "now I`m going to practice the operators "

puts "Frutillas: #{40+20/3}"

puts 5+6+3-2-5 / 3+1