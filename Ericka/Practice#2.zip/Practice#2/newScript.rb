valueNum1 = 3
valueNum2 = 3
valueNum3 = 2

sum = (valueNum1 + valueNum2) / valueNum3
#in the next line, we apply the first type of output, print the variable.
puts "#{sum}"

valueString1 = "Follow the string"
valueString2 = "echo"

#in the next line, we apply the second type of output, print directly the operation.
puts "#{valueString2 + valueString1}"