=begin
	in this script, first I want to show in the output the script`s 
	objective, and it is practice the operators with variables learned in ruby language
=end
valueFrutillas = 40+20/3
valueX = 5+6+3-2-5 / 3+1
valueErrorDisplay 
objective = "now I`m going to practice the operators"

puts "#{objective}"

puts "Frutillas: #{valueFrutillas}"

puts "#{valueX}"