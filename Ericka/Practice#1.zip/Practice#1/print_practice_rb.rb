print "first line"
#in the first line up we are using "print"
puts "second line"
#in the second line up we are using "puts"
print "third line"
puts "hello"
print "world"
puts "BDT"
print "jalasoft"
=begin
	
that is a script with the objetive to 
see the difference between "print"
and "puts" for the BDT class 	
=end